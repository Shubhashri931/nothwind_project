package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.RegionNotFoundException;
import com.example.demo.model.Region;

public interface RegionService {

	Region getRegionById(int RegionNumber) throws RegionNotFoundException;

	List<Region> getAllRegions();

	void createRegion(Region region);

	Region updateRegion(Region Region) throws RegionNotFoundException;

	void deleteRegion(int RegionNumber) throws RegionNotFoundException;

}