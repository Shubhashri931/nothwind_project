package com.example.demo.model;

import java.io.Serializable;

public class OrderDetailsId implements Serializable {
	
	private int OrderID;
    private int ProductID;
    
    public OrderDetailsId(int orderID, int productID) {
		super();
		OrderID = orderID;
		ProductID = productID;
	}
	public int getOrderID() {
		return OrderID;
	}
	public void setOrderID(int orderID) {
		OrderID = orderID;
	}
	public int getProductID() {
		return ProductID;
	}
	public void setProductID(int productID) {
		ProductID = productID;
	}
	public OrderDetailsId() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
}