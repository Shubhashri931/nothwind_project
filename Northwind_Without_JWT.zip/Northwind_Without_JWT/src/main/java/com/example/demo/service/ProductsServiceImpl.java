

package com.example.demo.service;

import java.util.Collections;

import java.util.List;

import java.util.Map;

import java.util.stream.Collectors;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

 

import com.example.demo.model.Products;

import com.example.demo.exception.ProductsNotFoundException;

import com.example.demo.repository.ProductsRepository;

 

@Service

public class ProductsServiceImpl implements ProductsService{

	@Autowired

	ProductsRepository productsRepository;

 

	@Override

	public Products getProductsById(int productsNumber) throws ProductsNotFoundException {


		if (productsRepository.findById(productsNumber).isEmpty())


			throw new ProductsNotFoundException("the products with" + productsNumber + "does not exists");


		return productsRepository.findById(productsNumber).get();

	}

 

	@Override

	public List<Products> getAllProducts() {

		return productsRepository.findAll();

	}

 

	@Override

	public void createProducts(Products products) {

		productsRepository.save(products);

 

	}

 

	@Override

	public Products updateProducts(Products products) throws ProductsNotFoundException {

		int productsId = products.getProductId();

		if (productsRepository.findById(productsId).isEmpty()) {

	        throw new ProductsNotFoundException("The products with ID " + productsId + " does not exist");

	    }

	    return productsRepository.save(products);

	}

 

	@Override

	public void deleteProducts(int productsNumber) throws ProductsNotFoundException {


		if (productsRepository.findById(productsNumber).isEmpty())


			throw new ProductsNotFoundException("the products with" + productsNumber + "does not exists");

		productsRepository.delete(productsRepository.findById(productsNumber).get());

 

	}

 

	@Override

	public List<Products> getDiscounted(int discounted) {

	    return productsRepository.findByDiscounted(discounted);

	}

 

	@Override

    public List<Products> getProductsByUnitPriceLessThan(double unitPrice) {

        return productsRepository.findByUnitPriceLessThan(unitPrice);

    }

 

	@Override

	public List<Products> getQuantityPerUnit(int quantityPerUnit) {

		// TODO Auto-generated method stub

		return productsRepository.findByQuantityPerUnit(quantityPerUnit);

	}

 

	

	@Override

	public List<Products> getPCategoryName(String categoryName) {

	    return null;

	}


 

	@Override

	public List<Map<String, String>> getProductDetails() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<String> getSuppliersByProductCount(int productCount) {

		// TODO Auto-generated method stub

		return null;

	}

 

	

	@Override

	public List<Products> getProductsByUnitInStock(int unitsInStock) {

	    // Assuming you have a method in your repository to retrieve products by unitsInStock

	    List<Products> products = productsRepository.findByUnitsInStock(unitsInStock);

 

	    if (products.isEmpty()) {

	        // You can decide how to handle the case where no products are found for the given unitsInStock.

	        // For example, you can throw an exception or return an empty list as shown here.

	        return Collections.emptyList();

	    }

 

	    return products;

	}

 

	@Override

    public List<Products> getProductsUnitsOnOrderGreaterThanZero() {

        // Assuming you have a method in your repository to retrieve products with unitsOnOrder > 0

        List<Products> products = productsRepository.findByUnitsOnOrderGreaterThan(0);

 

        if (products.isEmpty()) {

            // You can decide how to handle the case where no products meet the criteria.

            // For example, you can throw an exception or return an empty list as shown here.

            return Collections.emptyList();

        }

 

        return products;

    }

 

	@Override

    public List<Object[]> getOutOfStockProducts() {

    	return null;

        //return productsRepository.findProductDataOutOfStock();


}

 

    @Override

    public Products getProductWithMaxPrice() {

        return productsRepository.findFirstByOrderByUnitPriceDesc();

    }

 

	@Override

	public List<Products> getProductsByUnitPriceGreaterThanOthers() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsBySupplierId(int supplierId) {

	    List<Products> products = productsRepository.findBySupplierId(supplierId); 

	    return products;

	}

 

 

	@Override

	public List<Products> getProductsBySupplierIda(int supplierId) {


	    List<Products> products = productsRepository.getProductsBySupplierId(supplierId);

 

	    if (products.isEmpty()) {


	        return Collections.emptyList();

	    }

 

	    double totalUnitPrice = 0.0;

	    int productCount = 0;

 

	    for (Products product : products) {

	        totalUnitPrice += product.getUnitPrice();

	        productCount++;

	    }

 

	    double averageUnitPrice = totalUnitPrice / productCount;

	    List<Products> filteredProducts = products.stream()

	            .filter(product -> product.getUnitPrice() < averageUnitPrice)

	            .collect(Collectors.toList());

 

	    return filteredProducts;

	}

 

 

	@Override

    public List<Products> getProductsByUnitPriceGreaterThanAny() {

        return productsRepository.findProductsByUnitPriceGreaterThanAny();

    }

	@Override

    public List<Products> getDiscontinuedProducts() {

        return productsRepository.findByDiscounted(0); // Assuming 1 indicates discontinued products

    }


	@Override

    public List<Products> getProductsByCategoryName(String categoryName) {

        return productsRepository.findByCategoriesCategoryName(categoryName);

    }

}