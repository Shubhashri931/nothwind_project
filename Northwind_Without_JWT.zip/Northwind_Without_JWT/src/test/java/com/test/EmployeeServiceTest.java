package com.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employees;
import com.example.demo.repository.EmployeesRepository;
import com.example.demo.service.EmployeeServiceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

class EmployeeServiceImplTest {

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Mock
    private EmployeesRepository employeeRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEmployeeById() throws EmployeeNotFoundException {
        int employeeNumber = 1;
        Employees expectedEmployee = new Employees();
        expectedEmployee.setId(employeeNumber);
        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.of(expectedEmployee));

        Employees result = employeeService.getEmployeeById(employeeNumber);

        assertEquals(expectedEmployee, result);
    }

    @Test
    void testGetEmployeeById_ShouldThrowNotFoundException() {
        int employeeNumber = 1;
        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> employeeService.getEmployeeById(employeeNumber));
    }

    @Test
    void testGetAllEmployees() {
        List<Employees> expectedEmployees = new ArrayList<>();
        when(employeeRepository.findAll()).thenReturn(expectedEmployees);

        List<Employees> result = employeeService.getAllEmployees();

        assertEquals(expectedEmployees, result);
    }

    @Test
    void testCreateEmployee() {
        Employees employee = new Employees();
        employeeService.createEmployee(employee);

        verify(employeeRepository, times(1)).save(employee);
    }

    @Test
    void testUpdateEmployee() throws EmployeeNotFoundException {
        Employees employee = new Employees();
        employee.setId(1);
        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.of(employee));

        Employees updatedEmployee = employeeService.updateEmployee(employee);

        assertEquals(employee, updatedEmployee);
        verify(employeeRepository, times(1)).save(employee);
    }

    @Test
    void testUpdateEmployee_ShouldThrowNotFoundException() {
        Employees employee = new Employees();
        employee.setId(1);
        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> employeeService.updateEmployee(employee));
    }

    @Test
    void testDeleteEmployee() throws EmployeeNotFoundException {
        int employeeNumber = 1;
        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.of(new Employees()));

        employeeService.deleteEmployee(employeeNumber);

        verify(employeeRepository, times(1)).deleteById(employeeNumber);
    }

    @Test
    void testDeleteEmployee_ShouldThrowNotFoundException() {
        int employeeNumber = 1;
        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> employeeService.deleteEmployee(employeeNumber));
    }

    
}
