package com.example.demo.exception;

public class ShippersNotFoundException extends Exception {

    private String message;

    public ShippersNotFoundException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
