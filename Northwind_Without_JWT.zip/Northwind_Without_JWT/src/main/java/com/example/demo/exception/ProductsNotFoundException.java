package com.example.demo.exception;

public class ProductsNotFoundException extends Exception{
	String message;

	public ProductsNotFoundException(String message) {
		this.message = message;

	}

	public String getMessage() {
		return message;

	}
}


