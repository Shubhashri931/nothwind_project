package com.example.demo.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;

import java.util.Set;

@Entity
@Table(name = "Territories")
public class Territories {

	@Id
	@Column(name = "TerritoryID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int TerritoryId;

	@Column(name = "TERRITORY_DESCRIPTION")
	private String TerritoryDescription;

	@ManyToMany(mappedBy = "territories", fetch = FetchType.LAZY)
	@JsonIgnore
	private Set<Employees> employees = new HashSet<>();

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "REGION_ID")
	@JsonIgnore
	private Region region;

	public int getTerritoryId() {

		return TerritoryId;

	}

	public void setTerritoryId(int territoryId) {

		TerritoryId = territoryId;

	}

	public String getTerritoryDescription() {

		return TerritoryDescription;

	}

	public void setTerritoryDescription(String territoryDescription) {

		TerritoryDescription = territoryDescription;

	}

	public Set<Employees> getEmployees() {

		return employees;

	}

	public void setEmployees(Set<Employees> employees) {

		this.employees = employees;

	}

	public Region getRegion() {

		return region;

	}

	public void setRegion(Region region) {

		this.region = region;

	}

	public void setRegionId(int regionId) {
		// Create a new Region object and set its RegionId
		Region newRegion = new Region();
		newRegion.setRegionId(regionId);

		// Set the new Region object as the region for this Territory
		this.region = newRegion;
	}

	public void setRegion(int regionId) {
		// TODO Auto-generated method stub

	}

}