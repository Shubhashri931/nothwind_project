package com.example.demo.model;
import javax.persistence.*;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Employees")
public class Employees {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "EmployeeID")
    private int id;
    
    @Column(name="LAST_NAME")
    private String lastName;

	
	@Column(name="FIRST_NAME")
    private String firstName;

	
	@Column(name="TITLE")
    private String title; //jobtitle

	
	@Column(name="TITLE_OF_COURTESY")
    private String titleOfCourtesy; // no

	
	@Column(name="BIRTH_DATE")
    private Date birthDate;

	
	@Column(name="HIRE_DATE")
    private Date hireDate;

	
	@Column(name="ADDRESSS")
    private String address;
	
	
	@Column(name="CITY")
    private String city;

	
	@Column(name="REGION")
    private String region;

	
	@Column(name="POSTAL_CODE")
    private String postalCode;

	
	@Column(name="COUNTRY")
    private String country;

	
	@Column(name="HOME_PHONE")
    private String homePhone;

	
	@Column(name="EXTENSION")
    private String extension;

	
//	@Column(name="PHOTO")
//    private byte[] photo;

	
	@Column(name="NOTES")
    private String notes;

	
	@Column(name="REPORTS_TO")
    private Integer reportsTo;

	
	@Column(name="PHOTO_PATH")
    private String photoPath;


    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "EmployeeTerritories",
        joinColumns = @JoinColumn(name = "EmployeeID"),
        inverseJoinColumns = @JoinColumn(name = "TerritoryID")
    )
    private Set<Territories> territories = new HashSet<>();
    
    
    @OneToMany(mappedBy = "employees", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Orders> orders; 
   
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Set<Territories> getTerritories() {
		return territories;
	}

	public void setTerritories(Set<Territories> territories) {
		this.territories = territories;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitleOfCourtesy() {
		return titleOfCourtesy;
	}

	public void setTitleOfCourtesy(String titleOfCourtesy) {
		this.titleOfCourtesy = titleOfCourtesy;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	/*
	 * public byte[] getPhoto() { return photo; }
	 * 
	 * public void setPhoto(byte[] photo) { this.photo = photo; }
	 */

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public  Integer getReportsTo() {
		return reportsTo;
	}

	public void setReportsTo( Integer reportsTo) {
		this.reportsTo = reportsTo;
	}

	public String getPhotoPath() {
		return photoPath;
	}

	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}

}
