package com.example.demo.model;

import java.util.*;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "REGION")
public class Region {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "REGION_ID")
	@JsonIgnore	
	private int RegionId;

	
	@Column(name = "REGION_DESCRIPTION")
	private String RegionDescription;

	
	@OneToMany(mappedBy = "region", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Territories> territories;

	
	public int getRegionId() {
		return RegionId;
		
	}

	public void setRegionId(int regionId) {
		RegionId = regionId;

	}

	public String getRegionDescription() {
		return RegionDescription;

	}

	public void setRegionDescription(String regionDescription) {
		RegionDescription = regionDescription;

	}

	public List<Territories> getTerritories() {
		return territories;

	}

	public void setTerritories(List<Territories> territories) {
		this.territories = territories;

	}

}