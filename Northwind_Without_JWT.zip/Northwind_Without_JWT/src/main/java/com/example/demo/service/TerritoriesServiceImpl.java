package com.example.demo.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Territories;
import com.example.demo.exception.TerritoriesNotFoundException;
import com.example.demo.repository.TerritoriesRepository;

@Service
public class TerritoriesServiceImpl implements TerritoriesService{
	@Autowired
	TerritoriesRepository territoriesRepository;

	@Override
	public Territories getTerritoriesById(int territoriesNumber) throws TerritoriesNotFoundException {
		
		if (territoriesRepository.findById(territoriesNumber).isEmpty())
			
			throw new TerritoriesNotFoundException("the products with" + territoriesNumber + "does not exists");
		
		return territoriesRepository.findById(territoriesNumber).get();
	}

	@Override
	public List<Territories> getAllTerritories() {
		return territoriesRepository.findAll();
	}

	@Override
	public void createTerritories(Territories territories) {
		territoriesRepository.save(territories);

	}

	@Override
	public Territories updateTerritories(Territories territories) throws TerritoriesNotFoundException {
		int territoriesId = territories.getTerritoryId();
		if (territoriesRepository.findById(territoriesId).isEmpty()) {
	        throw new TerritoriesNotFoundException("The territories with ID " + territoriesId + " does not exist");
	    }
	    return territoriesRepository.save(territories);
	}

	@Override
	public void deleteTerritories(int territoriesNumber) throws TerritoriesNotFoundException {
		
		if (territoriesRepository.findById(territoriesNumber).isEmpty())
			
			throw new TerritoriesNotFoundException("the territories with" + territoriesNumber + "does not exists");
		territoriesRepository.delete(territoriesRepository.findById(territoriesNumber).get());

	}

	@Override
	public void createTerritory(Territories territory) {
	    // Save the territory object to the database
	    territoriesRepository.save(territory);
	}


	@Override
	public Territories updateTerritory(Territories territory) throws TerritoriesNotFoundException {
	    int territoryId = territory.getTerritoryId();
	    
	    // Check if the territory with the given ID exists in the database
	    if (!territoriesRepository.existsById(territoryId)) {
	        // Handle the case where the territory does not exist, you can throw an exception or return null
	        // For example, you can throw a custom exception TerritoriesNotFoundException
	        throw new TerritoriesNotFoundException("Territory with ID " + territoryId + " not found");
	    }
	    
	    // Update the territory by saving the provided object
	    return territoriesRepository.save(territory);
	}

	@Override
	public Territories getTerritoryById(int territoryId) throws TerritoriesNotFoundException {
	    // Use the repository to find a Territory by its ID
	    return territoriesRepository.findById(territoryId)
	            .orElseThrow(() -> new TerritoriesNotFoundException("Territory with ID " + territoryId + " not found"));
	}

}


