package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Categories;
import com.example.demo.exception.CategoriesNotFoundException;
import com.example.demo.service.CategoriesService;

@RestController
@RequestMapping("/api/category")
public class CategoriesController {

    @Autowired
    private CategoriesService categoriesService;

    // Endpoint to add a new category
    @PostMapping("/add")
    public ResponseEntity<String> addCategory(@RequestBody Categories category) {
        categoriesService.createCategories(category);
        return new ResponseEntity<>("Record Added Successfully!!", HttpStatus.OK);
    }

    // Endpoint to get all categories
    @GetMapping("/")
    public ResponseEntity<List<Categories>> getAllCategories() {
        List<Categories> categories = categoriesService.getAllCategories();
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    // Endpoint to update the description of a category by ID
    @PutMapping("/edit/{id}")
    public ResponseEntity<Categories> updateCategoryDescription(
            @PathVariable int id,
            @RequestBody Categories category) throws CategoriesNotFoundException {
        category.setCategoryId(id); // Set the category ID
        Categories updatedCategory = categoriesService.updateCategories(category);
        return new ResponseEntity<>(updatedCategory, HttpStatus.OK);
    }

    // Endpoint to search for a category by its name
    @GetMapping("/Categoryname/{Categoryname}")
    public ResponseEntity<List<Categories>> searchCategoryByName(@PathVariable String Categoryname) throws CategoriesNotFoundException {
        List<Categories> category = categoriesService.getCategoriesByName(Categoryname);
        return ResponseEntity.ok(category);
    }
}
