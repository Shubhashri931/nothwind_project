package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.model.Customers;
import com.example.demo.service.CustomersService;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/customers")
public class CustomersController {

    private final CustomersService customersService;

    @Autowired
    public CustomersController(CustomersService customersService) {
        this.customersService = customersService;
    }

    // Add new Customer Object in DB
    @PostMapping("/")
    public ResponseEntity<String> addCustomer(@RequestBody Customers customer) {
        try {
            customersService.addCustomer(customer);
            return new ResponseEntity<>("Record Created Successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Validation failed: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Get all Customers
    @GetMapping("/getAll")
    public ResponseEntity<List<Customers>> getAllCustomers() {
        List<Customers> customers = customersService.getAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    // Search Customers by CompanyName
    @GetMapping("/CompanyName/{companyName}")
    public ResponseEntity<List<Customers>> searchCustomersByCompanyName(@PathVariable String companyName) {
        List<Customers> customers = customersService.getCustomersByCompanyName(companyName);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    // Search Customers by ContactTitle
    @GetMapping("/ContactTitle/{contactTitle}")
    public ResponseEntity<List<Customers>> searchCustomersByContactTitle(@PathVariable String contactTitle) {
        List<Customers> customers = customersService.getCustomersByContactTitle(contactTitle);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    // Search Customers by Country
    @GetMapping("/Country/{country}")
    public ResponseEntity<List<Customers>> searchCustomersByCountry(@PathVariable String country) {
        List<Customers> customers = customersService.getCustomersByCountry(country);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    
    // Search Customers by City
    @GetMapping("/City/{city}")
    public ResponseEntity<List<Customers>> searchCustomersByCity(@PathVariable String city) {
        List<Customers> customers = customersService.getCustomersByCity(city);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    // Search Customers by Region
    @GetMapping("/Region/{region}")
    public ResponseEntity<List<Customers>> searchCustomersByRegion(@PathVariable String region) {
        List<Customers> customers = customersService.getCustomersByRegion(region);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    
    
    @GetMapping("/UniqueContactTitle")
    public ResponseEntity<Object> getUniqueContactTitles() {
        Set<String> uniqueContactTitles = customersService.getUniqueContactTitles();
        
        if (uniqueContactTitles != null && !uniqueContactTitles.isEmpty()) {
            return ResponseEntity.ok(uniqueContactTitles);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("No unique contact titles found."); // You can customize this error message
        }
    }


   
    @PutMapping("/Edit/{customerId}/assignAddress")
    public ResponseEntity<Void> assignAddressToCustomer(
            @PathVariable int customerId,
            @RequestParam String newAddress) {
        try {
            Customers existingCustomer = customersService.getCustomerById(customerId);

            if (existingCustomer != null) {
                existingCustomer.setAddress(newAddress);
                customersService.saveCustomer(existingCustomer);
                return ResponseEntity.noContent().build();
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (CustomerNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/Edit/{customerId}/updateContactName")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void updateContactNameOfCustomer(
            @PathVariable int customerId,
            @RequestParam String newContactName) {
        try {
            Customers existingCustomer = customersService.getCustomerById(customerId);

            if (existingCustomer != null) {
                existingCustomer.setContactName(newContactName);
                customersService.saveCustomer(existingCustomer);
            } else {
                throw new CustomerNotFoundException("Customer not found");
            }
        } catch (CustomerNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found", e);
        }
    }
	
    
	  //Update Region of a Customer using PATCH
	  @PatchMapping("/Edit/{CustomerID}")
	  public ResponseEntity<Void> updateCustomerRegionAndCompanyName(@PathVariable int CustomerId,@RequestBody Customers updatedCustomer) throws CustomerNotFoundException {
		  try {
	      Customers existingCustomer = customersService.getCustomerById(CustomerId);

	      if (existingCustomer != null) {
	          // Update the 'region' field if it exists in the updatedCustomer
	          if (updatedCustomer.getRegion() != null) {
	              existingCustomer.setRegion(updatedCustomer.getRegion());
	          }

	          // Update the 'companyName' field if it exists in the updatedCustomer
	          if (updatedCustomer.getCompanyName() != null) {
	              existingCustomer.setCompanyName(updatedCustomer.getCompanyName());
	          }

	          // Save the updated customer
	          customersService.saveCustomer(existingCustomer);

	          return ResponseEntity.noContent().build(); // 204 No Content
	      } else {
	          // Customer not found
	          return ResponseEntity.notFound().build();
	      }
		  }catch(CustomerNotFoundException e) {
			  return ResponseEntity.notFound().build();
		  }
		  
	  }


    // Search the Customer by Fax
    @GetMapping("/Fax/{fax}")
    public ResponseEntity<Customers> searchCustomerByFax(@PathVariable String fax) {
        Customers customer = customersService.getCustomerByFax(fax);
        if (customer != null) {
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Display the number of Customers from each Country
    @GetMapping("/NumberofCustomersByCountry")
    public ResponseEntity<Map<String, Long>> getNumberOfCustomersByCountry() {
        Map<String, Long> numberOfCustomersByCountry = customersService.getNumberOfCustomersByCountry();

        if (numberOfCustomersByCountry != null && !numberOfCustomersByCountry.isEmpty()) {
            return new ResponseEntity<>(numberOfCustomersByCountry, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Search Customers whose Region does not contain null value
    @GetMapping("/RegionNotnull")
    public ResponseEntity<List<Customers>> searchCustomersWithRegionNotNull() {
        List<Customers> customers = customersService.getCustomersWithRegionNotNull();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }
}



