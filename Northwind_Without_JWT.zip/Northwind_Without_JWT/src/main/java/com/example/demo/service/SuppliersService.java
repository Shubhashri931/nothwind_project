package com.example.demo.service;

import java.util.List;
import java.util.function.Supplier;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.SuppliersNotFoundException;
import com.example.demo.model.Employees;
import com.example.demo.model.Suppliers;

public interface SuppliersService {

	Suppliers getSuppliersById(String country) throws SuppliersNotFoundException;

	List<Suppliers> getAllSuppliers();

	void createSuppliers(Supplier supplier);

	Suppliers updateSuppliers(Suppliers Suppliers) throws SuppliersNotFoundException;

	void deleteSuppliers(int SuppliersNumber) throws SuppliersNotFoundException;
		
    List<Suppliers> getSuppliersByCountry(String country);

    List<Suppliers> getSuppliersByRegionNotNull();

    List<Suppliers> getSuppliersByContactTitleContaining(String title);

    List<Object[]> getNumberOfSuppliersByCountry();

	Suppliers getSuppliersById(int SuppliersNumber) throws SuppliersNotFoundException;

	Employees updateEmployee(Employees employee) throws EmployeeNotFoundException;

	Suppliers updateSupplier(Suppliers suppliers) throws SuppliersNotFoundException;

	void createSuppliers(Suppliers Suppliers);
	
}