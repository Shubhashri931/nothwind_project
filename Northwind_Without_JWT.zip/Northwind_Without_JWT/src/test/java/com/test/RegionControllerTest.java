package com.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;
import com.example.demo.controller.RegionController;
import com.example.demo.exception.RegionNotFoundException;
import com.example.demo.model.Region;
import com.example.demo.service.RegionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

public class RegionControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private RegionController regionController;

    @Mock
    private RegionService regionService;

    public RegionControllerTest() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(regionController).build();
    }

    @Test
    public void testGetRegionById() throws RegionNotFoundException {
        // Prepare a mock Region
        Region mockRegion = new Region();
        mockRegion.setRegionId(1);
       

        // Mock the getRegionById method of regionService
        when(regionService.getRegionById(1)).thenReturn(mockRegion);

        Region region = regionController.getRegionById(1).getBody();
		assertNotNull(region);
		assertEquals(1, region.getRegionId());
    }

    @Test
    public void testGetRegionById_NotFound() throws RegionNotFoundException {
        // Mock the getRegionById method of regionService to throw RegionNotFoundException
        when(regionService.getRegionById(1)).thenThrow(RegionNotFoundException.class);

        // Test the getRegionById method for a non-existing Region
        assertThrows(RegionNotFoundException.class, () -> regionController.getRegionById(1));
    }

    @Test
    public void testGetAllRegions() {
        // Prepare a list of mock Regions
        List<Region> mockRegions = new ArrayList<>();
        Region mockRegion1 = new Region();
        mockRegion1.setRegionId(1);
       
        mockRegions.add(mockRegion1);

        Region mockRegion2 = new Region();
        mockRegion2.setRegionId(2);
       
        mockRegions.add(mockRegion2);

        // Mock the getAllRegions method of regionService
        when(regionService.getAllRegions()).thenReturn(mockRegions);

        // Test the getAllRegions method
        List<Region> regions = regionController.getAllRegions();
        assertNotNull(regions);
        assertEquals(2, regions.size());
      
    }
    
   

    @Test
    public void testUpdateRegion() throws Exception {
        Region region = new Region();
        region.setRegionId(1);
       
        // Mock the updateRegion method
        when(regionService.updateRegion(Mockito.any(Region.class))).thenReturn(region);

        ObjectMapper objectMapper = new ObjectMapper();
        String regionJson = objectMapper.writeValueAsString(region);

        ResultActions resultActions = mockMvc.perform(put("/api/region/put/1")
                .contentType("application/json")
                .content(regionJson));

        resultActions.andExpect(status().isNoContent());

        verify(regionService, times(1)).updateRegion(Mockito.any(Region.class));
    }

   

    @Test
    public void testDeleteRegion() throws Exception {
        mockMvc.perform(delete("/api/region/1"))
                .andExpect(status().isNoContent());

        verify(regionService, times(1)).deleteRegion(1);
    }


   
}
