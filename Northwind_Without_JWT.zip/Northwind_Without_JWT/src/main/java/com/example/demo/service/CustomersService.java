package com.example.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.model.Customers;

public interface CustomersService {

	List<Customers> getAllCustomers();

	void createCustomer(Customers Customer);

	Customers updateCustomer(Customers Customer) throws CustomerNotFoundException;
	
	Customers updateCustomer1(Customers Customer) throws CustomerNotFoundException;


	void deleteCustomer(int CustomerNumber) throws CustomerNotFoundException;

	void addCustomer(Customers customer);

	List<Customers> getCustomersByCompanyName(String companyName);

	List<Customers> getCustomersByContactTitle(String contactTitle);

	List<Customers> getCustomersByCountry(String country);

	Customers getCustomerById(int customerId)throws CustomerNotFoundException;

	void saveCustomer(Customers existingCustomer);

	List<Customers> getCustomersByCity(String city);

	List<Customers> getCustomersByRegion(String region);

	Set<String> getUniqueContactTitles();

	Customers getCustomerByFax(String fax);

	Map<String, Long> getNumberOfCustomersByCountry();

	List<Customers> getCustomersWithRegionNotNull();

	

}