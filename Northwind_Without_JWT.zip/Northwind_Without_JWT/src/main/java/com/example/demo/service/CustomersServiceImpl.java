package com.example.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customers;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.exception.CustomerNotFoundException;

@Service
public class CustomersServiceImpl implements CustomersService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public Customers getCustomerById(int customerId) throws CustomerNotFoundException {
		
		if (customerRepository.findById(customerId).isEmpty())
			
			throw new CustomerNotFoundException("the Customer with" + customerId + "does not exists");
		
		return customerRepository.findById(customerId).get();
	}

	@Override
	public List<Customers> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public void createCustomer(Customers customer) {
		customerRepository.save(customer);

	}

	@Override
	public Customers updateCustomer(Customers customer) throws CustomerNotFoundException {
	    int customerId = (int) customer.getCustomerId(); // Use getCustomerId() to get the customer ID
	    if (customerRepository.findById((int) customerId).isEmpty()) {
	        throw new CustomerNotFoundException("The Customer with ID " + customerId + " does not exist");
	    }
	    return customerRepository.save(customer);
	}
	//With this code, you should be able to update a customer using their customerId as the primary key. Make sure that your database schema and the Customers class definition are in sync, and the customerId field matches the primary key column in the CUSTOMERS table.



	@Override
	public void deleteCustomer(int customerId) throws CustomerNotFoundException {
		
		if (customerRepository.findById(customerId).isEmpty())
			
			throw new CustomerNotFoundException("the Customer with" + customerId + "does not exists");
		customerRepository.delete(customerRepository.findById(customerId).get());

	}

	@Override
	public void addCustomer(Customers customer) {
		// TODO Auto-generated method stub
		customerRepository.save(customer);
		
		
	}

	@Override
	public List<Customers> getCustomersByCompanyName(String companyName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> getCustomersByContactTitle(String contactTitle) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> getCustomersByCountry(String country) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void saveCustomer(Customers existingCustomer) {
		// TODO Auto-generated method stub
		customerRepository.save(existingCustomer);
		
	}

	@Override
	public List<Customers> getCustomersByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> getCustomersByRegion(String region) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<String> getUniqueContactTitles() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customers getCustomerByFax(String fax) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Long> getNumberOfCustomersByCountry() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> getCustomersWithRegionNotNull() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customers updateCustomer1(Customers Customer) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return customerRepository.save(Customer);
	}

	

}

