package com.example.demo.controller;

import java.util.List;
import java.util.function.Supplier;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.SuppliersNotFoundException;
import com.example.demo.model.Suppliers;
import com.example.demo.service.SuppliersService;

import io.micrometer.core.ipc.http.HttpSender;

@RestController
@RequestMapping("/api/supplier")
public class SuppliersController {

    @Autowired
    SuppliersService suppliersService;

    // POST /api/supplier - Add new Supplier
    @PostMapping("/add")
    public ResponseEntity<String> addSupplier(@Valid @RequestBody Suppliers supplier) {
        suppliersService.createSuppliers(supplier);
        return ResponseEntity.ok("Record Added Successfully!!");
    }

    // GET /api/supplier - Get all Suppliers
    @GetMapping("/all")
    public ResponseEntity<List<Suppliers>> getAllSuppliers() {
        List<Suppliers> suppliers = suppliersService.getAllSuppliers();
        return ResponseEntity.ok(suppliers);
    }

    // PUT /api/supplier/edit/{id} - Update the Address, City, PostalCode, Country of the Supplier
    @PutMapping("/edit/{id}")
    public ResponseEntity<Suppliers> updateSupplier(@PathVariable int id, @RequestBody Suppliers supplier) {
        try {
            supplier.setSupplierID(id);
            suppliersService.updateSupplier(supplier);
            return new ResponseEntity<>(supplier,HttpStatus.CREATED);
        } catch (SuppliersNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/supplier/Country/{Country} - Search Suppliers by Country
    @GetMapping("/Country/{country}")
    public ResponseEntity<List<Suppliers>> getSuppliersByCountry(@PathVariable String country) {
        List<Suppliers> suppliers = suppliersService.getSuppliersByCountry(country);
        return ResponseEntity.ok(suppliers);
    }

    // GET /api/supplier/Regionnotnull - Search Suppliers whose Region is not null
    @GetMapping("/Regionnotnull")
    public ResponseEntity<List<Suppliers>> getSuppliersWithRegionNotNull() {
        List<Suppliers> suppliers = suppliersService.getSuppliersByRegionNotNull();
        return ResponseEntity.ok(suppliers);
    }

    // GET /api/supplier/Title/{title} - Search Suppliers whose Contact Title contains a word 'Manager'
    @GetMapping("/Title/{title}")
    public ResponseEntity<List<Suppliers>> getSuppliersByTitle(@PathVariable String title) {
        List<Suppliers> suppliers = suppliersService.getSuppliersByContactTitleContaining(title);
        return ResponseEntity.ok(suppliers);
    }

    // GET /api/supplier/NumberofSupplierbyCountry - Display the number of Suppliers from each Country
    @GetMapping("/NumberofSupplierbyCountry")
    public ResponseEntity<List<Object[]>> getNumberOfSuppliersByCountry() {
        List<Object[]> suppliersCountByCountry = suppliersService.getNumberOfSuppliersByCountry();
        return ResponseEntity.ok(suppliersCountByCountry);
    }
}
