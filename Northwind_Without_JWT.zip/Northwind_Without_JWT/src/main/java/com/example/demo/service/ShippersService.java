package com.example.demo.service;

 

import java.util.List;

 

import org.springframework.stereotype.Service;

 

import com.example.demo.exception.ShippersNotFoundException;
import com.example.demo.model.Shippers;

 

 

public interface ShippersService {

 

    Shippers getShipperById(int shipperId) throws ShippersNotFoundException;

 

    List<Shippers> getAllShippers();

 

    void createShipper(Shippers shipper);

 

    Shippers updateShipper(Shippers shipper) throws ShippersNotFoundException;

 

    void deleteShipper(int shipperId) throws ShippersNotFoundException;

 

	List<Shippers> getShippersByCompanyName(String companyName) throws ShippersNotFoundException;

 

	List<Shippers> findAllByOrderByCompanyName();

	Shippers updateShipperById(Shippers shipper) throws ShippersNotFoundException;

 

}