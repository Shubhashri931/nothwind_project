
package com.example.demo.service;

import com.example.demo.exception.ProductsNotFoundException;

import com.example.demo.model.Products;

 

import java.util.List;

import java.util.Map;

 

public interface ProductsService {

	Products getProductsById(int ProductsNumber) throws ProductsNotFoundException;

 

	List<Products> getAllProducts();

 

	void createProducts(Products products);

 

	Products updateProducts(Products products) throws ProductsNotFoundException;

 

	void deleteProducts(int productsNumber) throws ProductsNotFoundException;

 

	List<Products> getDiscounted(int discounted);

 

	List<Products> getProductsByUnitPriceLessThan(double unitPrice);

 

	List<Products> getQuantityPerUnit(int quantityPerUnit);

 

	List<Products> getProductsByCategoryName(String categoryName);

 

	List<Map<String, String>> getProductDetails();

 

	List<String> getSuppliersByProductCount(int productCount);

 

	List<Products> getProductsByUnitInStock(int unitInStock);

 

	List<Products> getProductsUnitsOnOrderGreaterThanZero();

 

	List<Object[]> getOutOfStockProducts();

 

	List<Products> getProductsByUnitPriceGreaterThanOthers();

 

	List<Products> getProductsBySupplierId(int supplierId);

 

	List<Products> getPCategoryName(String categoryName);

 

	List<Products> getProductsBySupplierIda(int supplierId);




	Products getProductWithMaxPrice();

 

	List<Products> getProductsByUnitPriceGreaterThanAny();

 

	List<Products> getDiscontinuedProducts();


 

}