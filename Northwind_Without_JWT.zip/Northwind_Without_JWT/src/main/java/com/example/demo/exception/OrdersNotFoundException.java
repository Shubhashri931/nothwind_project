package com.example.demo.exception;

public class OrdersNotFoundException extends Exception {
	
	String message;
	
	public OrdersNotFoundException(String message) {
		this.message=message;
	}

	public String getMessage() {
		return message;
	}

}
