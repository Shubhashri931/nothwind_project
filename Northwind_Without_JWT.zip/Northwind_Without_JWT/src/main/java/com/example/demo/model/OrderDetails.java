package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import org.springframework.context.annotation.ComponentScan;

@Entity
@IdClass(OrderDetailsId.class)
@ComponentScan("com.example.demo.model")
@Table(name="ORDER_DETAILS")
public class OrderDetails implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ORDER_ID")
	private int OrderID;
	
	@Id
	@Column(name="PRODUCT_ID")
	private int ProductID;
	
	@Column(name="UNIT_PLACE")
	private double Unitprice;
	
	@Column(name="QUANTITY")
	private int Quantity;
	
	@Column(name="DISCOUNT")
	private double Discount;
	
	
	@ManyToOne
    @JoinColumn(name = "PRODUCT_ID", insertable = false, updatable = false)
    private Products products;
	
	
	
	@ManyToOne
    @JoinColumn(name = "ORDER_ID", insertable = false, updatable = false)
    private Orders order;
	

	
	
	

	public int getOrderID() {
		return OrderID;
	}

	public void setOrderID(int orderID) {
		OrderID = orderID;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public double getUnitprice() {
		return Unitprice;
	}

	public void setUnitprice(double unitprice) {
		Unitprice = unitprice;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public double getDiscount() {
		return Discount;
	}

	public void setDiscount(double discount) {
		Discount = discount;
	}

}
