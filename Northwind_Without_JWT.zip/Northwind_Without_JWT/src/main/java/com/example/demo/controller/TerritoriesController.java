package com.example.demo.controller;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

 

import com.example.demo.model.Region;
import com.example.demo.model.Territories;
import com.example.demo.dto.TerritoriesRegionDTO.TerritoryDTO;
import com.example.demo.exception.RegionNotFoundException;
import com.example.demo.exception.TerritoriesNotFoundException;
import com.example.demo.service.RegionService;
import com.example.demo.service.TerritoriesService;

 

@RestController
@RequestMapping("/api/territories")
public class TerritoriesController {

 

    @Autowired
    private TerritoriesService territoriesService;

 

    @Autowired
    private RegionService regionService;
    
    
    // Endpoint to add a new territory
    @PostMapping("/Region/{RegionId}")
    public ResponseEntity<String> addTerritorys(@PathVariable("RegionId") int RegionId,@RequestBody Territories territory) throws RegionNotFoundException {

        territoriesService.createTerritory(territory);
        Region region=regionService.getRegionById(RegionId);
        territory.setRegion(region);
        territoriesService.createTerritories(territory);
        return new ResponseEntity<>("Record Added Successfully!!", HttpStatus.OK);
    }

 

    // Endpoint to get all territories
    @GetMapping("/getAll")
    public ResponseEntity<Iterable<Territories>> getAllTerritories() {
        Iterable<Territories> territories = territoriesService.getAllTerritories();
        return new ResponseEntity<>(territories, HttpStatus.OK);
    }

 

    @PutMapping("/edit/{id}")
    public ResponseEntity<Territories> updateTerritoryDetails(
            @PathVariable int id,
            @RequestBody TerritoryDTO updateDTO) throws TerritoriesNotFoundException {
        try {
            // Retrieve the existing Territories entity by its ID
            Territories existingTerritory = territoriesService.getTerritoryById(id);

 

            // Update the territories_description field from DTO
            existingTerritory.setTerritoryDescription(updateDTO.getTerritoryDescription());

 

            // Set the regionId to update the association with the Region
            existingTerritory.setRegion(updateDTO.getRegionId());

 

            // Save the updated entity
            Territories savedTerritory = territoriesService.updateTerritory(existingTerritory);

 

            return new ResponseEntity<>(savedTerritory, HttpStatus.OK);
        } catch (TerritoriesNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

 

        @GetMapping("/territoryid/{territoryId}")
        public ResponseEntity<Territories> getTerritoryById(@PathVariable int territoryId) throws TerritoriesNotFoundException {
            Territories territory = territoriesService.getTerritoryById(territoryId);
            return new ResponseEntity<>(territory, HttpStatus.OK);
        }

 

    }